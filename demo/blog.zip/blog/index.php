<?php

/**
 * TinyMVC
 * 
 * PHP framework based on MVC architecture
 * 
 * @copyright 2019-2020 - N'Guessan Kouadio Elisée (eliseekn@gmail.com)
 * @license MIT (https://opensource.org/licenses/MIT)
 * @link https://github.com/eliseekn/tinymvc
 */

/**
 * Main application file
 */

//include core files
require_once 'app/core/config.php';
require_once 'app/core/loader.php';
require_once 'app/core/router.php';

//set error_reporting() and display_errors parameters
//change application environment settings in app/core/config.php
if (APP_ENV === 'development') {
    ini_set('display_errors', 1);
    ini_set('error_reporting', -1);
} else if (APP_ENV === 'production') {
    ini_set('display_errors', 0);
    ini_set('error_reporting', 0);
} else {
    echo 'The application environment is not set properly.';
    exit();
}

//load database
load_database(); //comment this entire line if you are not going to use database

//include necessaries helpers
load_helpers(
    'url',
    'pagination',
    'session',
    'security',
    'utils',
    'files'
);

//start url routing
$router = new Router();

//add custom routes
$router->add_custom_route(
    'home',
    'home',
    array(
        '' => 'index',
        'page' => 'index'
    )
);

$router->add_custom_route(
    'posts',
    'posts',
    array(
        'slug' => 'index'
    )
);

$router->add_custom_route(
    'admin',
    'admin',
    array(
        '' => 'index'
    )
);

$router->add_custom_route(
    'dashboard',
    'dashboard',
    array(
        'index' => 'posts'
    )
);

//dispath parameters
$router->dispatch();
