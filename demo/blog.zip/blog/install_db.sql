-- create admin table
CREATE TABLE `admin` (
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`username` varchar(255) NOT NULL,
	`password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- create posts table
CREATE TABLE `posts` (
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`image` varchar(255) NOT NULL,
	`title` varchar(255) NOT NULL,
	`slug` varchar(255) NOT NULL,
	`content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- insert default admin infos
INSERT INTO `admin` (`username`, `password`) VALUES ('admin', 'admin');
