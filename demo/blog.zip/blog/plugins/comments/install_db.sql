-- create comments table
CREATE TABLE `comments` (
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`post_id` int(11) NOT NULL,
	`author` varchar(255) NOT NULL,
	`content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
