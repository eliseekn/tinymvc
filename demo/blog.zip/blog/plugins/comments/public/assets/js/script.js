async function postData(url, data = null) {
	const response = await fetch(url, {
		method: 'post',
		body: data
	});

	return response;
}

document.addEventListener('DOMContentLoaded', () => {
	document.querySelector('#add-post-form').addEventListener('submit', event => {
		event.preventDefault();

		const dashboardUrl = event.target.getAttribute('action');
		
		const formData = new FormData();
		formData.append('title', document.querySelector('#add-post-form #post-title').value);
		formData.append('content', document.querySelector('#add-post-form #post-content').value);
		formData.append('image', document.querySelector('#add-post-form #post-image').files[0]);

		postData(dashboardUrl + '/add_post', formData).then(() => {
			window.location.href = dashboardUrl;
		});
	});

	document.querySelectorAll('#remove-post').forEach(element => {
		element.addEventListener('click', event => {
			event.preventDefault();
	
			const dashboardUrl = event.target.getAttribute('href');
			const postId = event.target.dataset.postId;
			
			if (window.confirm('Are you sure you want to delete this post?')) {
				postData(dashboardUrl + '/delete_post/' + postId).then(() => {
					window.location.href = dashboardUrl;
				});
			}
		});
	});	

	document.querySelectorAll('#edit-post').forEach(element => {
		element.addEventListener('click', event => {
			event.preventDefault();
			
			document.querySelector('#edit-post-form').dataset.postId = event.target.dataset.postId;
			document.querySelector('#edit-post-form #post-title').value = event.target.dataset.postTitle;
			document.querySelector('#edit-post-form #post-content').value = event.target.dataset.postContent;

			$('#edit-post-modal').modal('show');
		});
	});

	document.querySelector('#edit-post-form').addEventListener('submit', event => {
		event.preventDefault();

		const dashboardUrl = event.target.getAttribute('action');
		
		const formData = new FormData();
		formData.append('id', event.target.dataset.postId);
		formData.append('title', document.querySelector('#edit-post-form #post-title').value);
		formData.append('content', document.querySelector('#edit-post-form #post-content').value);
		formData.append('image', document.querySelector('#edit-post-form #post-image').files[0]);

		postData(dashboardUrl + '/edit_post', formData).then(() => {
			window.location.href = dashboardUrl;
		});
	});
});