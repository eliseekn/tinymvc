<?php

class AdminModel extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function login(string $username, string $password) {
        $admin_infos = $this->select()
            ->from('admin')
            ->where('username', '=', $username)
            ->and('password', '=', $password)
            ->fetch();

        return $admin_infos === NULL ? false : true;
    }
}