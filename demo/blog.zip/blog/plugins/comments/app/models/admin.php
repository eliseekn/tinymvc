<?php

class AdminModel extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function login(string $username, string $password) {
        $admin = $this->select()
            ->from('admin')
            ->where('username', '=', $username)
            ->fetch();

        return compare_hash($password, $admin['password']);
    }
}