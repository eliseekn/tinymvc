<?php

class CommentsModel extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_all() {
        $comments = $this->select()
            ->from('comments')
            ->order_by('id', 'DESC')
            ->fetch_array();

        return $comments;
    }

    public function get_post_comments(int $post_id) {
        $comments = $this->select()
            ->from('comments')
            ->where('post_id', '=', $post_id)
            ->order_by('id', 'DESC')
            ->fetch_array();

        return $comments;
    }

    public function add_comment(string $author, string $content, int $post_id) {
        $this->insert('comments', 
            array(
                'author' => $author,
                'content' => $content,
                'post_id' => $post_id
            )    
        );
    }

    public function delete_comment(int $id) {
        $this->delete()
            ->from('comments')
            ->where('id', '=', $id)
            ->limit(1)
            ->execute_query();
    }

    public function comments_count(int $post_id) {
        $comments_count = $this->select()
            ->from('comments')
            ->where('post_id', '=', $post_id)
            ->rows_count();

        return $comments_count;
    }
}