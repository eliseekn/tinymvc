<?php
header('Content-Type: application/json');

class CommentsController {

	public function __construct() {
		$this->comments = load_model('comments');
	}

	public function get_post_comments(int $post_id) {
		$comments = $this->comments->get_post_comments($post_id);
		echo json_encode($comments);
	}

	public function add_comment(string $author, string $content, int $post_id) {
		$author = sanitize_input($author);
		$content = sanitize_input($content);
		$this->comments->add_comment($author, $content, $post_id);
	}

	public function total_post_comments(int $post_id) {
		$count = $this->comments->total_post_comments($post_id);
		echo json_encode($count);
	}
}
