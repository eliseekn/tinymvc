<?php

class AdminController {

	public function __construct() {
		$this->admin = load_model('admin');
	}

	public function index(int $page = 1) {
		if (session_exists('admin')) {
			redirect('dashboard');
        }

		load_template('login', 'admin', 
			array(
				'page_title' => 'The Mount Everest Blog - Comments',
				'page_description' => 'Comments administration page'
			)
		);
    }
    
	public function login(string $username, string $password) {
        $username = sanitize_input($username);
		$password = sanitize_input($password);
		
		if (!$this->admin->login($username, $password)) {
            redirect('admin');
        }

		create_session('admin', '');
        redirect('dashboard');
	}

	public function logout() {
		close_session('admin');
		redirect('admin');
	}
}
