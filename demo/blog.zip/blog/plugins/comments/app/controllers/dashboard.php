<?php

class DashboardController {

	public function __construct() {
		$this->comments = load_model('comments');
	}

	public function index() {
		if (!session_exists('admin')) {
			redirect('admin');
		}

		$data['page_title'] = 'The Mount Everest Blog - Comments Plugin Dashboard';
		$data['page_description'] = 'Comments Plugin Dashboard';
		$data['comments'] = $this->comments->get_all();

		load_template('dashboard', 'admin', $data);
    }
    
    public function delete_comment(int $id) {
		$this->comments->delete_comment($id);
    }
}
