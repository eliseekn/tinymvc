<?php

class DashboardController {

	public function __construct() {
		$this->comments = load_model('comments');
	}

	public function index(int $page = 1) {
		if (!session_exists('admin')) {
			redirect('admin');
		}
		
		$pagination = generate_pagination($page, $this->comments->total_comments(), 10);

		load_template('dashboard', 'admin', 
			array(
				'page_title' => 'The Mount Everest Blog - Dashboard',
				'page_description' => 'Comments administratin dashboard',
				'comments' => $this->comments->get_comments(10, $pagination['first_item']),
				'pagination' => array(
					'page' => $pagination['page'],
					'total_pages' => $pagination['total_pages'],
					'previous_page' => $pagination['page'] - 1,
					'next_page' => $pagination['page'] + 1
				)
			)
		);
    }
    
	public function delete_comment(int $id) {
		$this->comments->delete_comment($id);
    }
}
