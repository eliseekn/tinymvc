<div class="container w-25 mt-5">
    <h1>Login</h1>

    <div class="card shadow p-5">
        <form method="post" action="<?= WEB_ROOT. 'admin/login' ?>">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" class="form-control" required>
            </div>

            <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-lg btn-dark">Submit</button>
        </form>
    </div>
</div>