<div class="container my-5">
    <h1 class="mb-3 text-center">Comments</h1>
    
    <table class="table my-5">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Comment</th>
                <th scope="col">Author</th>
                <th scope="col">Post</th>
                <th scope="col"></th>
            </tr>
        </thead>

        <tbody>

        <?php foreach ($comments as $comment) { ?>

            <tr>
                <th scope="row"><?= $comment['id'] ?></th>
                <td><?= $comment['content'] ?></td>
                <td><?= $comment['author'] ?></td>
                <td><?= $comment['post_id'] ?></td>
                <td>
                    <a id="remove-comment" data-post-id="<?= $comment['id'] ?>" href="<?= base_url('dashboard') ?>">
                        Remove comment
                    </a>
                </td>
            </tr>
        
        <?php } ?>

        </tbody>
    </table>

	<nav class="my-5">
		<ul class="pagination pagination-lg justify-content-center">

			<?php if ($pagination['page'] > 1) { ?>
			
			<li class="page-item">
				<a class="page-link text-dark" href="<?= base_url('dashboard/page/'. $pagination['previous_page']) ?>">
					<i class="fas fa-angle-double-left"></i>
				</a>
			</li>

			<?php } ?>

			<?php if ($pagination['total_pages'] > 1) { ?>
			
			<li class="page-item page-link text-dark">
				Page <?= $pagination['page'] ?>/<?= $pagination['total_pages'] ?>
			</li>
			
			<?php } ?>

			<?php if ($pagination['page'] < $pagination['total_pages']) { ?>

			<li class="page-item">
				<a class="page-link text-dark" href="<?= base_url('dashboard/page/'. $pagination['next_page']) ?>">
					<i class="fas fa-angle-double-right"></i>
				</a>
			</li>

			<?php } ?>
		</ul>
	</nav>

    <div class="text-center">
        <a href="<?= base_url('admin/logout') ?>" class="btn btn-lg btn-dark">Logout</a>
    </div>
</div>
