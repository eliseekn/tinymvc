-- create counter table
CREATE TABLE `counter` (
	`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`post_id` int(11) NOT NULL,
	`views` int(11) NOT NULL DEFAULT 1,
	`likes` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
