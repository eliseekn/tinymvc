<?php

class CounterModel extends Model {

    public function __construct() {
        parent::__construct();
    }

    private function post_exists(int $post_id) {
        $post = $this->select()
            ->from('counter')
            ->where('post_id', '=', $post_id)
            ->fetch();

        return !empty($post); 
    }

    private function update_count(int $post_id, string $counter, bool $inc) {
        $count = $this->select($counter)
            ->from('counter')
            ->where('post_id', '=', $post_id)
            ->fetch();

        $i = $count[$counter];

        if ($inc) {
            $i++;
        } else {
            $i--;
        }

        $this->update('counter')
            ->set(
                array(
                    $counter => $i
                )
            )
            ->where('post_id', '=', $post_id)
            ->execute_query();
    }

    public function add_like(int $post_id) {
        if (!$this->post_exists($post_id)) {
            $this->insert('counter',
                array(
                    'post_id' => $post_id,
                    'likes' => 1
                )
            );
        } else {
            $this->update_count($post_id, 'likes', true);
        }
    }

    public function remove_like(int $post_id) {
        $this->update_count($post_id, 'likes', false);
    }

    public function update_views(int $post_id) {
        if (!$this->post_exists($post_id)) {
            $this->insert('counter',
                array(
                    'post_id' => $post_id,
                    'views' => 1
                )
            );
        } else {
            $this->update_count($post_id, 'views', true);
        }
    }

    public function views_count(int $post_id) {
        $post = $this->select()
            ->from('counter')
            ->where('post_id', '=', $post_id)
            ->fetch();

        return $post['views'];
    }

    public function likes_count(int $post_id) {
        $post = $this->select()
            ->from('counter')
            ->where('post_id', '=', $post_id)
            ->fetch();

        return $post['likes'];
    }
}