<?php
header('Content-Type: application/json');

class CounterController {

	public function __construct() {
		$this->counter = load_model('counter');
	}

	public function add_like(int $post_id) {
		$this->counter->add_like($post_id);
	}

	public function remove_like(int $post_id) {
		$this->counter->remove_like($post_id);
	}

	public function update_views(int $post_id) {
		$this->counter->update_views($post_id);
	}

	public function views_count(int $post_id) {
		$count = $this->counter->views_count($post_id);
		echo json_encode($count);
	}

	public function likes_count(int $post_id) {
		$count = $this->counter->likes_count($post_id);
		echo json_encode($count);
	}
}
