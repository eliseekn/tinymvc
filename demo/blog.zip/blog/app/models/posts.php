<?php

class PostsModel extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_posts(int $limit, int $offset) {
        $posts = $this->select()
            ->from('posts')
            ->order_by('id', 'DESC')
            ->limit($limit, $offset)
            ->fetch_array();

        return $posts;
    }

    public function get_post_slug(string $slug) {
        $post = $this->select()
            ->from('posts')
            ->where('slug', '=', $slug)
            ->fetch();

        return $post;
    }

    public function get_post_id(int $id) {
        $post = $this->select()
            ->from('posts')
            ->where('id', '=', $id)
            ->fetch();

        return $post;
    }

    public function add_post(string $title, string $slug, string $image, string $content) {
        $this->insert('posts', 
            array(
                'title' => $title,
                'slug' => $slug,
                'image' => $image,
                'content' => $content
            )    
        );
    }

    public function edit_post(int $id, string $title, string $slug, string $content) {
        $this->update('posts')
            ->set(
                array(
                    'title' => $title,
                    'slug' => $slug,
                    'content' => $content
                )
            )
            ->where('id', '=', $id)
            ->execute_query();
    }

    public function edit_post_image(int $post_id, string $image) {
        $post = $this->get_post_id($post_id);
        unlink(DOCUMENT_ROOT .'blog/public/assets/img/posts/'. $post['image']);

        $this->update('posts')
            ->set(
                array(
                    'image' => $image
                )
            )
            ->where('id', '=', $post_id)
            ->execute_query();
    }

    public function delete_post(int $id) {
        $post = $this->get_post_id($id);
        unlink(DOCUMENT_ROOT .'blog/public/assets/img/posts/'. $post['image']);

        $this->delete()
            ->from('posts')
            ->where('id', '=', $id)
            ->limit(1)
            ->execute_query();
    }

    public function total_posts() {
        $total_posts = $this->select()
            ->from('posts')
            ->rows_count();

        return $total_posts;
    }
}