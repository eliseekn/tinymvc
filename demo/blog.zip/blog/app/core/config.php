<?php

/**
 * TinyMVC
 * 
 * PHP framework based on MVC architecture
 * 
 * @copyright 2019-2020 - N'Guessan Kouadio Elisée (eliseekn@gmail.com)
 * @license MIT (https://opensource.org/licenses/MIT)
 * @link https://github.com/eliseekn/tinymvc
 */

/**
 * Application configuration file
 */

//reset execution timeout
set_time_limit(0);

//roots directory
define('WEB_DOMAIN', 'http://localhost/blog/'); //domain
define('DOCUMENT_ROOT', $_SERVER['DOCUMENT_ROOT'] . '/'); //document directory full path
define('LOGS_DIR', DOCUMENT_ROOT . 'blog/logs/'); //logs directory

//environment configuration (development or production)
define('APP_ENV', 'production');

//database configuration
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'eliseekn');
define('DB_NAME', 'blog');
