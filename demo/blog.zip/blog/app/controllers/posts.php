<?php

class PostsController {

	public function __construct() {
		$this->posts = load_model('posts');
	}

	public function index(string $slug) {
		$post = $this->posts->get_post_slug($slug);
		
        $fetch_results = fetch('get',
            array(
                base_url('plugins/comments/comments/get_post_comments/'. $post['id']),
                base_url('plugins/comments/comments/total_post_comments/'. $post['id']),
                base_url('plugins/counter/counter/update_views/'. $post['id'])
            )
        );

		load_template('post', 'main', 
			array(
				'page_title' => 'The Mount Everest Blog',
				'page_description' => 'Blog post content',
				'post' => $post,
                'comments' => $fetch_results['content'][0],
                'total_comments' => $fetch_results['content'][1]
			)
		);
	}
}
