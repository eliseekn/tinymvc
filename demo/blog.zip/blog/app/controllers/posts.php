<?php

class PostsController {

	public function __construct() {
		$this->posts = load_model('posts');
	}

	public function index(string $slug) {
		$post = $this->posts->get_post($slug);

		$fetch_results = fetch('get', 
			array(
				WEB_ROOT .'plugins/comments/comments/get_comments/'. $post['id'],
				WEB_ROOT .'plugins/comments/comments/comments_count/'. $post['id'],
				WEB_ROOT .'plugins/counter/counter/update_views/'. $post['id']
			)
		);

		$data['page_title'] = 'The Mount Everest Blog';
		$data['page_description'] = 'Posts about mountaineering';
		$data['post'] = $post;
		$data['comments'] = $fetch_results['content'][0];
		$data['comments_count'] = $fetch_results['content'][1];
		
		load_template('posts', 'main', $data);
	}
}
