<?php

class DashboardController {

	public function __construct() {
		$this->posts = load_model('posts');
	}

	public function index() {
		if (!session_exists('admin')) {
			redirect('admin');
		}

		$data['page_title'] = 'The Mount Everest Blog - Dashboard';
		$data['page_description'] = 'Posts about the mountaineering';
		$data['posts'] = $this->posts->get_all_posts();

		load_template('dashboard', 'admin', $data);
    }
    
    public function add_post(string $title, string $content) {
		$title = sanitize_input($title);
		$content = sanitize_input($content);
		$slug = generate_slug($title);

		if (!empty($_FILES['image']['name'])) {
			$image = WEB_ROOT .'public/assets/img/posts/'. basename($_FILES['image']['name']);
			$full_path = DOCUMENT_ROOT .'blog/public/assets/img/posts/'. basename($_FILES['image']['name']);
			
			if (move_uploaded_file($_FILES['image']['tmp_name'], $full_path)) {
				$this->posts->add_post($title, $slug, $image, $content);
			}
		}
	}
	
	public function edit_post(int $id, string $title, string $content) {
		$title = sanitize_input($title);
		$content = sanitize_input($content);
		$slug = generate_slug($title);

		if (!empty($_FILES['image']['name'])) {
			$image = WEB_ROOT .'public/assets/img/posts/'. basename($_FILES['image']['name']);
			$full_path = DOCUMENT_ROOT .'blog/public/assets/img/posts/'. basename($_FILES['image']['name']);
			
			if (move_uploaded_file($_FILES['image']['tmp_name'], $full_path)) {
				$this->posts->edit_post($id, $title, $slug, $image, $content);
			}
		}
	}

    public function delete_post(int $id) {
		$this->posts->delete_post($id);
    }
}
