<?php

class DashboardController {

	public function __construct() {
		$this->posts = load_model('posts');
	}

	public function index(int $page = 1) {
		if (!session_exists('admin')) {
			redirect('admin');
		}
		
		$pagination = generate_pagination($page, $this->posts->total_posts(), 3);

		load_template('dashboard', 'admin', 
			array(
				'page_title' => 'The Mount Everest Blog - Dashboard',
				'page_description' => 'Administratin dashboard',
				'posts' => $this->posts->get_posts(3, $pagination['first_item']),
				'pagination' => array(
					'page' => $pagination['page'],
					'total_pages' => $pagination['total_pages'],
					'previous_page' => $pagination['page'] - 1,
					'next_page' => $pagination['page'] + 1
				)
			)
		);
    }
    
	public function add_post(string $title, string $content) {
		$title = sanitize_input($title);
		$content = sanitize_input($content);
		$slug = generate_slug($title);
        
        if (upload_file('image', 'blog/public/assets/img/posts', false, $image)) {
            $this->posts->add_post($title, $slug, $image, $content);
		}
    }
    
    public function edit_post(int $id, string $title, string $content) {
		$title = sanitize_input($title);
		$content = sanitize_input($content);
        $slug = generate_slug($title);
        
        $this->posts->edit_post($id, $title, $slug, $content);
    }
    
    public function edit_post_image(int $post_id) {
        if (upload_file('image', 'blog/public/assets/img/posts', false, $image)) {
            $this->posts->edit_post_image($post_id, $image);
        }
	}

	public function delete_post(int $id) {
		$this->posts->delete_post($id);
	}
}
