<?php

class HomeController {

	public function __construct() {
		$this->posts = load_model('posts');
	}

	public function index(int $page = 1) {
		$pagination = generate_pagination($page, $this->posts->posts_count(), 5);

		$data['page_title'] = 'The Mount Everest Blog';
		$data['page_description'] = 'Posts about mountaineering';
		$data['posts'] = $this->posts->get_posts(5, $pagination['first_item']);
		$data['pagination']['page'] = $pagination['page'];
		$data['pagination']['total_pages'] = $pagination['total_pages'];
		$data['pagination']['previous_page'] = $pagination['page'] - 1;
		$data['pagination']['next_page'] = $pagination['page'] + 1;

		load_template('home', 'main', $data);
	}
}
