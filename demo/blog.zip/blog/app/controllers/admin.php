<?php

class AdminController {

	public function __construct() {
		$this->admin = load_model('admin');
	}

	public function index() {
        if (session_exists('admin')) {
			redirect('dashboard');
        }
        
		$data['page_title'] = 'The Mount Everest Blog - Login';
		$data['page_description'] = 'Posts about the mountaineering';

		load_template('login', 'admin', $data);
    }
    
	public function login(string $username, string $password) {
		if ($this->admin->login($username, $password)) {
			create_session('admin',
				array(
					'username' => $username
				)
			);

			redirect('dashboard');
		} else {
			redirect('admin');
		}
	}

	public function logout() {
		destroy_session('admin');
		redirect('admin');
	}
}
