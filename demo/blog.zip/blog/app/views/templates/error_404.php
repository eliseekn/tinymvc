<div class="container text-center" style="padding: 5em 0"> 
	<h2 class="py-3">The page you have requested does not exists on this server.</h2>
	<a href="<?= base_url('home') ?>" class="btn btn-lg btn-dark">Go back home</a>
</div>