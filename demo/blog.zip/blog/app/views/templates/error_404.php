<div class="container text-center" style="padding: 10em 0"> 
	<h1 class="font-weight-bold">Error 404: <em>Page not found</em></h1>
	<h2 class="py-3">The page you've requested doesn't exists on this server.</h2>
	<a href="<?= WEB_ROOT ."home" ?>" class="btn btn-lg btn-dark">Go back home</a>
</div>