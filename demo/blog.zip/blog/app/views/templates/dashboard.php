<div class="container my-5">
    <h1 class="mb-3 text-center">Dashboard</h1>
    
    <div class="text-center">
        <button class="btn btn-lg btn-dark" data-toggle="modal" data-target="#add-post-modal">
            Add post
        </button>
    </div>

    <table class="table my-5">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Post title</th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>

        <tbody>

        <?php foreach ($posts as $post) { ?>

            <tr>
                <th scope="row"><?= $post['id'] ?></th>
                <td><?= $post['title'] ?></td>
                <td>
                    <a id="edit-post" 
                        data-post-id="<?= $post['id'] ?>" 
                        data-post-title="<?= $post['title'] ?>" 
                        data-post-content="<?= $post['content'] ?>" 
                        href="#">Edit post</a>
                </td>
                <td>
                    <a id="remove-post" data-post-id="<?= $post['id'] ?>" href="#">
                        Remove post
                    </a>
                </td>
            </tr>
        
        <?php } ?>

        </tbody>
    </table>

    <div class="text-center">
        <a href="<?= WEB_ROOT. 'home' ?>" class="btn btn-lg btn-dark mr-4">Go back home</a>
        <a href="<?= WEB_ROOT. 'admin/logout' ?>" class="btn btn-lg btn-dark">Logout</a>
    </div>

    <div id="add-post-modal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add post</h5>
                    <button class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form id="add-post-form" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="text" id="post-title" placeholder="Post title" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <textarea id="post-content" rows="5" placeholder="Post content" class="form-control" required></textarea>
                        </div>

                        <input type="file" name="image" id="post-image" class="form-control-file" required>
                    </div>
                
                    <div class="modal-footer">
                        <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <input type="submit" class="btn btn-dark" value="Add">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="edit-post-modal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit post</h5>
                    <button class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form id="edit-post-form" data-post-id="" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="text" id="post-title" placeholder="Post title" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <textarea id="post-content" rows="5" placeholder="Post content" class="form-control" required></textarea>
                        </div>

                        <input type="file" name="image" id="post-image" class="form-control-file" required>
                    </div>
                
                    <div class="modal-footer">
                        <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <input type="submit" class="btn btn-dark" value="Edit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="<?= WEB_ROOT. 'public/assets/js/script.js' ?>"></script>