<section class="container my-5">
	<div class="row row-cols-2">

	<?php foreach ($posts as $post) { ?>

		<article class="col mb-5">
			<div class="card">
				<img 
					src="<?= base_url('public/assets/img/posts/'. $post['image']) ?>" 
					class="card-img-top" 
					alt="Post image">
				
				<div class="card-body">
				<h2 class="card-title post-title"><?= $post['title'] ?></h2>
				<p class="card-text mt-3 text-justify"><?= generate_exerpt($post['content']) ?></p>

				<div class="d-flex justify-content-between text-align-center mt-4">
					<div class="d-flex align-items-center">
						<div class="mr-2 btn btn-lg btn-dark">
							<span  
								class="mr-1 views-count"
								data-post-id="<?= $post['id'] ?>">0</span>
							<i class="fa fa-eye"></i>
						</div>
						
						<div class="mr-2 btn btn-lg btn-dark">
							<span 
								class="mr-1 likes-count" 
								data-post-id="<?= $post['id'] ?>">0</span>
							<i class="fa fa-thumbs-up"></i>
						</div>

						<div class="btn btn-lg btn-dark">
							<span 
								class="comments-count mr-1" 
								data-post-id="<?= $post['id'] ?>">0</span>
							<i class="fa fa-comments"></i>
						</div>
					</div>

					<a 
						href="<?= base_url('posts/slug/'. $post['slug']) ?>" 
						data-post-id="<?= $post['id'] ?>" 
						class="btn btn-lg btn-dark read-more">Read more</a>
				</div>
			</div>
		</article>

	<?php } ?>

	</div>

	<nav class="my-5">
		<ul class="pagination pagination-lg justify-content-center">

			<?php if ($pagination['page'] > 1) { ?>
			
			<li class="page-item">
				<a class="page-link text-dark" href="<?= base_url('home/page/'. $pagination['previous_page']) ?>">
					<i class="fas fa-angle-double-left"></i>
				</a>
			</li>

			<?php } ?>

			<?php if ($pagination['total_pages'] > 1) { ?>
			
			<li class="page-item page-link text-dark">
				Page <?= $pagination['page'] ?>/<?= $pagination['total_pages'] ?>
			</li>
			
			<?php } ?>

			<?php if ($pagination['page'] < $pagination['total_pages']) { ?>

			<li class="page-item">
				<a class="page-link text-dark" href="<?= base_url('home/page/'. $pagination['next_page']) ?>">
					<i class="fas fa-angle-double-right"></i>
				</a>
			</li>

			<?php } ?>
		</ul>
	</nav>
</section>