//domain name
var webRoot = "http://localhost/blog/"

//post data with fetch api
async function postData(url, data = null) {
	const request = await fetch(url, {
		method: 'post',
		body: data
	})

	try {
		const response = await request.json()
		return response
	} catch(error) {
		//console.log(error)
	}
}

document.addEventListener('DOMContentLoaded', () => {
	//manage dashboard events 
	if (document.querySelector('#add-post-form')) {
		document.querySelector('#add-post-form').addEventListener('submit', event => {
			event.preventDefault()
	
			let formData = new FormData()
			formData.append('title', document.querySelector('#add-post-form #post-title').value)
			formData.append('content', document.querySelector('#add-post-form #post-content').value)
			formData.append('image', document.querySelector('#add-post-form #post-image').files[0])
	
			postData(webRoot + 'dashboard/add_post', formData).then(() => {
				window.location.href = webRoot + 'dashboard'
			})
		})
	}

	if (document.querySelectorAll('#remove-post')) {
		document.querySelectorAll('#remove-post').forEach(element => {
			element.addEventListener('click', event => {
				event.preventDefault()
		
				if (window.confirm('Are you sure you want to delete this post?')) {
					postData(webRoot + 'dashboard/delete_post/' + event.target.dataset.ppostId)
						.then(() => {
							window.location.href = webRoot + 'dashboard'
						})
				}
			})
		})
	}	

	if (document.querySelectorAll('#edit-post')) {
		document.querySelectorAll('#edit-post').forEach(element => {
			element.addEventListener('click', event => {
				event.preventDefault()
				
				document.querySelector('#edit-post-form').dataset.postId = event.target.dataset.postId
				document.querySelector('#edit-post-form #post-title').value = event.target.dataset.postTitle
				document.querySelector('#edit-post-form #post-content').value = event.target.dataset.postContent
	
				$('#edit-post-modal').modal('show')
			})
		})
	}

	if (document.querySelector('#edit-post-form')) {
		document.querySelector('#edit-post-form').addEventListener('submit', event => {
			event.preventDefault()
	
			let formData = new FormData()
			formData.append('id', event.target.dataset.postId)
			formData.append('title', document.querySelector('#edit-post-form #post-title').value)
			formData.append('content', document.querySelector('#edit-post-form #post-content').value)
	
			postData(webRoot + 'dashboard/edit_post', formData).then(() => {
				window.location.href = webRoot + 'dashboard'
			})
		})
	}

	if (document.querySelectorAll('#edit-post-image')) {
		document.querySelectorAll('#edit-post-image').forEach(element => {
			element.addEventListener('click', event => {
				event.preventDefault()
				document.querySelector('#edit-post-image-form').dataset.postId = event.target.dataset.postId
				$('#edit-post-image-modal').modal('show')
			})
		})
	}

	if (document.querySelector('#edit-post-image-form')) {
		document.querySelector('#edit-post-image-form').addEventListener('submit', event => {
			event.preventDefault()
	
			let formData = new FormData()
			formData.append('id', event.target.dataset.postId)
			formData.append('image', document.querySelector('#edit-post-image-form #post-image').files[0])
	
			postData(webRoot + 'dashboard/edit_post_image', formData).then(() => {
				window.location.href = webRoot + 'dashboard'
			})
		})
	}

	//manage blog events
	if (document.querySelector('#add-comment-form')) {
		document.querySelector('#add-comment-form').addEventListener('submit', event => {
			event.preventDefault()
	
			const postUrl = event.target.getAttribute('action')
	
			let formData = new FormData()
			formData.append('author', document.querySelector('#add-comment-form #comment-author').value)
			formData.append('content', document.querySelector('#add-comment-form #comment-content').value)
			formData.append('id', event.target.dataset.postId)
			
			postData(webRoot + 'plugins/comments/comments/add_comment', formData).then(() => {
				window.location.href = postUrl
			})
		})
	}

	if (document.querySelectorAll('.comments-count')) {
		document.querySelectorAll('.comments-count').forEach(element => {
			postData(webRoot + 'plugins/comments/comments/total_post_comments/' + element.dataset.postId)
				.then(data => {
					if (data !== null && data !== undefined) {
						element.innerHTML = data
					}
				})
		})
	}

	if (document.querySelector('#like-dislike')) {
		document.querySelector('#like-dislike').addEventListener('click', event => {
			event.preventDefault()
			
			if (event.target.innerText === 'Like') {
				event.target.innerText = 'Dislike'

				postData(webRoot + 'plugins/counter/counter/add_like/' + event.target.dataset.postId)
					.catch(error => {
						console.log(error)
					})
			} else {
				event.target.innerText = 'Like'

				postData(webRoot + 'plugins/counter/counter/remove_like/' + event.target.dataset.postId)
					.catch(error => {
						console.log(error)
					})
			}
		})
	}

	if (document.querySelectorAll('.views-count')) {
		document.querySelectorAll('.views-count').forEach(element => {
			postData(webRoot + 'plugins/counter/counter/views_count/' + element.dataset.postId)
				.then(data => {
					if (data !== null && data !== undefined) {
						element.innerHTML = data
					}
				})
		})
	}

	if (document.querySelectorAll('.likes-count')) {
		document.querySelectorAll('.likes-count').forEach(element => {
			postData(webRoot + 'plugins/counter/counter/likes_count/' + element.dataset.postId)
				.then(data => {
					if (data !== null && data !== undefined) {
						element.innerHTML = data
					}
				})
		})
	}
})